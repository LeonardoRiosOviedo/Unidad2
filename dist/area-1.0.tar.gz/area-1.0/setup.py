from setuptools import setup

setup (
    name='area',
    version='1.0',
    description='This module calculate volumenes',
    author='Leonardo Rios Oviedo',
    author_email='leo@gmail.com',
    url='http//www.utng.edu.mx',
    py_modules=['area']
)