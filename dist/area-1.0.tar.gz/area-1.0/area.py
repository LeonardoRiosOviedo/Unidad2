def rombo_perimetro (a: float) -> float:
    return 4* a


def bombo_area (D: float , d: float) ->float:
    return D * d / 2